#include <stdio.h>
#include <stdlib.h>

int main()
{
    int entero[5];
    float flotante[10];
    char caracter[5];
    int continuar;
    int posicion;
    int valor;

    do{
            //tomar posicion
        printf("Indique el indice del entero a cargar (maximo 5): ");
        scanf("%d \n", &posicion);

                //COMPROBARION DEL INDICE DENTRO DEL RANGO
            if(posicion > 5 && posicion < 1){
                printf("Error. Indique el indice del entero a cargar nuevamente (maximo 5): ");
                scanf("%d \n", &posicion);
            }
            //REDUZCO EL INDICE PARA CONTAR DESDE EL 0
        posicion = posicion-1;

            //tomar valor
        printf("Indique el valor: ");
        scanf("%d \n", &entero[posicion]);

        printf("Continuar: 1 | No: 0");
        scanf("%d", &continuar);
    }while(!continuar == 0);

    //IMPRIMO ARRAYS
        for(int i = 0; i <= 4;i++){
            printf("Entero: %d", entero[i]);
        }

        for(int i = 0; i <= 9;i++){
            printf("Flotante: %d", flotante[i]);
        }

        for(int i = 0; i <= 4;i++){
            printf("Caracter: %d", caracter[i]);
        }

        //MENSAJE DE FINALIZACION
        printf("Programa finalizado.");
    return 0;
}
