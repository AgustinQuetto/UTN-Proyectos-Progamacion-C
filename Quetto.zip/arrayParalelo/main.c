#include <stdio.h>
#include <stdlib.h>

#define MAX 3

int main()
{
    int legajo[MAX];
    float salario[MAX];
    int edad[MAX];
    float salarioAux;
    int i;
    float salarioMax;
    float salarioMin;

    for(i=0; i<MAX; i++)
    {
        printf("Ingrese legajo:\n");
        scanf("%d",&legajo[i]);

        system("cls");
        printf("Ingrese salario:\n");
        scanf("%f",&salarioAux);
        salario[i]=salarioAux;

        for(int i = 0; i < MAX; i++)
        {
            if(salario[i] < salarioAux)
            {
                salarioMax = salarioAux;
            }
        }

        system("cls");
        printf("Ingrese edad:\n");
        scanf("%d",&edad[i]);
    }

    system("cls");

    printf("Legajo\tSalario\tEdad");

    for(i=0; i<MAX; i++)
    {
        printf("\n%d\t%.2f\t%d",legajo[i], salario[i], edad[i]);
    }

    for(i=0; i<MAX; i++)
    {
        if(i==0 || salario[i] > mayor)
        {

        }

        if(i==0 || salario[i] > menor)
        {

        }
    }


    return 0;
}
