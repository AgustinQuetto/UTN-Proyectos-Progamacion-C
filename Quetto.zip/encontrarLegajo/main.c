#include <stdio.h>
#include <stdlib.h>

#define MAX 5
int main()
{
    int legajo[MAX] = {1,2,3,4,5};
    int edad[MAX] = {30,15,24,68,43};
    float sueldo[MAX] = {23600.43,12000.8,12800.25,16082.3,45781.8};
    int valorAux;

    printf("Ingrese el numero de legajo: ");
    fflush(stdin);
    scanf(" %d", &valorAux);

    for(int i=0;i<MAX;i++){
        if(valorAux == legajo[i]){
            printf("%d,\t %0.2f,\t %d", legajo[i], edad[i], sueldo[i]);
            break;
        }else{
            printf("Sin coincidencia en el indice %d\n", i);
        }
    }


    return 0;
}
